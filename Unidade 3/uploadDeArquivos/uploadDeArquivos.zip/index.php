<?php
header('Location: formularioUploadExcel.php');